﻿public interface IPermeable
{
    public int GetStat(EStat choice);
}