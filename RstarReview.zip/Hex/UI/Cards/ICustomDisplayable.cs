﻿public interface ICustomDisplayable
{
    public string GetCustomDisplay();
}