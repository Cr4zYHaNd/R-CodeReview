﻿using System;

public interface IContextMenuable
{
    public static void GetAllTypes()
    {
        throw new NotImplementedException();
    }

}