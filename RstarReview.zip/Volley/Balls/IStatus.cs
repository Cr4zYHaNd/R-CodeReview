﻿using System.Collections;
using UnityEngine;


public interface IStatus
{

    public void GiveStatus(PlayerStatusHandler player);

}
