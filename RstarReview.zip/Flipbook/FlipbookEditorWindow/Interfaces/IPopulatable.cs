using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IPopulatable
{
    public void Populate(Flipbook sourceClip);
    
}