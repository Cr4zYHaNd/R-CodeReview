using System;

// Example implementation of a Sentence that animates a hitbox, which is transform data and size data
[Serializable]
public class FBS_Hitbox : FlipbookSentence<FBW_Hitbox>
{
    public override void PreviewMute()
    {
    }

    public override void PreviewUnmute()
    {
    }

    public override void Evaluate(float alpha = 0)
    {
        //Do stuff
        //Yes
    }
}
